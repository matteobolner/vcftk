from ._version import __version__
from .vcforge import VCFClass
__all__ = [
    "__version__",
]
